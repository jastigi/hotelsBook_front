import { Component } from '@angular/core';
import { DpDatePickerModule, IDatePickerConfig } from 'ng2-date-picker';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [DpDatePickerModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  datePickerConfig: IDatePickerConfig = {
    drops: 'down',
    opens: 'right',
    format: 'DD/MM/YYYY'
  };

}
